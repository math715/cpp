install pcl libaray
sudo add-apt-repository ppa:v-launchpad-jochen-sprickerhof-de/pcl
sudo apt-get update
sudo apt-get install libpcl-dev


kdtree
http://pointclouds.org/documentation/tutorials/kdtree_search.php
